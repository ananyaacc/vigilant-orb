import 'package:url_launcher/url_launcher.dart';
import 'package:vigilantorb_flutter/database/db_helperr.dart';
import 'package:location/location.dart';

Future<void> sendEmergencyAlert(String userPhoneNumber) async {
  // Fetch user details
  DatabaseHelper dbHelper = DatabaseHelper();
  Map<String, dynamic>? user = await dbHelper.queryUser(userPhoneNumber);
  if (user != null) {
    // Get user's current location
    Location location = Location();
    LocationData? currentLocation = await location.getLocation();
    String latitude = currentLocation.latitude.toString();
    String longitude = currentLocation.longitude.toString();

    // Compose the alert message
    String alertMessage =
        "Emergency Alert! Current location: Latitude $latitude, Longitude $longitude.";

    // Send the alert to parents using default SMS app
    List<String> recipients = [
      user['parent_phone_number1'],
      user['parent_phone_number2'],
      user['parent_phone_number3'],
      user['parent_phone_number4']
    ];
    recipients.forEach((recipient) async {
      String url = 'sms:$recipient?body=$alertMessage';
      if (await canLaunch(url)) {
        await launch(url);
      } else {
        print('Could not launch SMS app.');
      }
    });

    // Play alert sound
    // AudioCache player = AudioCache();
    // player.play('alert_sound.mp3');

    // You can also play a loud sound here for added emphasis
    // For example, using audioplayers package
    // AudioCache player = AudioCache();
    // player.play('alert_sound.mp3');

    print('Emergency alert sent to parents.');
  } else {
    print('User not found.');
  }
}
