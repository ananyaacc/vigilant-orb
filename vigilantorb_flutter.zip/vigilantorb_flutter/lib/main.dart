import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'shake_detector.dart';
import 'voice_assistant.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await _requestMicrophonePermission();
  runApp(MyApp());
}

Future<void> _requestMicrophonePermission() async {
  var status = await Permission.microphone.request();
  if (status != PermissionStatus.granted) {
    print('Microphone permission denied');
  }
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Your App Title',
      initialRoute: '/',
      routes: {
        '/': (context) => MyHomePage(),
        '/voiceAssistant': (context) => VoiceAssistant(),
      },
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Home')),
      body: Center(
        child: ShakeDetectorWidget(
          onPhoneShake: () {
            Navigator.pushNamed(context, '/voiceAssistant');
          },
        ),
      ),
    );
  }
}
