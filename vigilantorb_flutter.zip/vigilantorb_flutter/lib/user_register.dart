import 'package:flutter/material.dart';
import 'package:vigilantorb_flutter/database/db_helperr.dart';
import 'package:vigilantorb_flutter/user_model.dart';
import 'package:vigilantorb_flutter/user_login.dart';

class UserRegisterPage extends StatefulWidget {
  @override
  _UserRegisterPageState createState() => _UserRegisterPageState();
}

class _UserRegisterPageState extends State<UserRegisterPage> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _phoneNumberController = TextEditingController();
  final _parentControllers = List<TextEditingController>.generate(
    4,
        (index) => TextEditingController(),
  );
  final _passwordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();

  final dbHelper = DatabaseHelper();

  bool _showParentFields = false;

  bool _passwordVisible = false;

  @override
  void dispose() {
    for (final controller in _parentControllers) {
      controller.dispose();
    }
    super.dispose();
  }

  Future<void> _registerUser() async {
    final name = _nameController.text;
    final email = _emailController.text;
    final phoneNumber = _phoneNumberController.text;
    final parent1 = _parentControllers[0].text;
    final parent2 = _parentControllers[1].text;
    final parent3 = _parentControllers[2].text;
    final parent4 = _parentControllers[3].text;
    final password = _passwordController.text;

    if (_formKey.currentState?.validate() ?? false) {
      if (parent1.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Parent phone number 1 is required!')),
        );
        return;
      }

      final user = User(
        name: name,
        email: email,
        userPhoneNumber: phoneNumber,
        parentPhoneNumber1: parent1,
        parentPhoneNumber2: parent2,
        parentPhoneNumber3: parent3,
        parentPhoneNumber4: parent4,
        password: password,
      );

      await dbHelper.insertUser(user.toMap());

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('User registration successful!')),
      );
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => LoginPage()),
      );

      _nameController.clear();
      _emailController.clear();
      _phoneNumberController.clear();
      for (final controller in _parentControllers) {
        controller.clear();
      }
      _passwordController.clear();
      _confirmPasswordController.clear();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('User Registration'),
        ),
        body: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage("assets/B.jpeg"),
              fit: BoxFit.cover,
            ),
          ),
          child: Center(
            child: SingleChildScrollView( // Wrap with SingleChildScrollView
              child: Card(
                elevation: 3.0,
                // Set the card color to transparent
                child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Form(
                    key: _formKey,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          'User Registration',
                          style: TextStyle(fontSize: 24.0, fontWeight: FontWeight.bold),
                        ),
                        SizedBox(height: 20.0),
                        TextFormField(
                          controller: _nameController,
                          decoration: InputDecoration(labelText: 'Name', icon: Icon(Icons.person)),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter your name';
                            }
                            return null;
                          },
                        ),

                        TextFormField(
                          controller: _emailController,
                          decoration: InputDecoration(labelText: 'Email', icon: Icon(Icons.email)),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter your email';
                            }
                            if (!value.contains('@') || value.indexOf('@') != value.lastIndexOf('@')) {
                              return 'Invalid email format';
                            }
                            return null;
                          },
                        ),
                        TextFormField(
                          controller: _phoneNumberController,
                          decoration: InputDecoration(labelText: 'Phone Number', icon: Icon(Icons.phone)),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter your phone number';
                            }
                            if (value.length != 10 || !RegExp(r'^[0-9]+$').hasMatch(value)) {
                              return 'Phone number must contain 10 digits';
                            }
                            return null;
                          },
                        ),
                        TextFormField(
                          controller: _parentControllers[0],
                          decoration: InputDecoration(labelText: 'Parent Phone Number 1', icon: Icon(Icons.person_pin)),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter your parent phone number';
                            }
                            if (value.length != 10 || !RegExp(r'^[0-9]+$').hasMatch(value)) {
                              return 'Phone number must contain 10 digits';
                            }
                            return null;
                          },
                        ),
                        if (_showParentFields)
                          ...List.generate(
                            3,
                                (index) => TextFormField(
                              controller: _parentControllers[index + 1],
                              decoration: InputDecoration(
                                  labelText: 'Parent Phone Number ${index + 2}', icon: Icon(Icons.person_pin)),
                            ),
                          ),
                        if (!_showParentFields)
                          IconButton(
                            icon: Icon(Icons.add),
                            onPressed: () {
                              setState(() {
                                _showParentFields = true;
                              });
                            },
                          ),
                        TextFormField(
                          controller: _passwordController,
                          obscureText: !_passwordVisible,
                          decoration: InputDecoration(
                            labelText: 'Password',
                            icon: Icon(Icons.lock),
                            suffixIcon: IconButton(
                              icon: Icon(
                                _passwordVisible ? Icons.visibility : Icons.visibility_off,
                              ),
                              onPressed: () {
                                setState(() {
                                  _passwordVisible = !_passwordVisible;
                                });
                              },
                            ),
                          ),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter a password';
                            }
                            if (value.length < 6) {
                              return 'Password must be at least 6 characters';
                            }
                            return null;
                          },
                        ),
                        TextFormField(
                          controller: _confirmPasswordController,
                          obscureText: !_passwordVisible,
                          decoration: InputDecoration(
                            labelText: 'Confirm Password',
                            icon: Icon(Icons.lock),
                            suffixIcon: IconButton(
                              icon: Icon(
                                _passwordVisible ? Icons.visibility : Icons.visibility_off,
                              ),
                              onPressed: () {
                                setState(() {
                                  _passwordVisible = !_passwordVisible;
                                });
                              },
                            ),
                          ),
                          validator: (value) {
                            if (value != _passwordController.text) {
                              return 'Passwords do not match';
                            }
                            return null;
                          },
                        ),
                        ElevatedButton(
                          onPressed: _registerUser,
                          child: Text('Register'),


                        ),
                        SizedBox(height: 10.0),
                        TextButton(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => LoginPage()),
                            );
                          },
                          child: Text("Already have an account? Log in"),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ));
  }
}
