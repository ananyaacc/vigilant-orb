class User {
  String name;
  String email;
  String userPhoneNumber;
  String parentPhoneNumber1;
  String? parentPhoneNumber2;
  String? parentPhoneNumber3;
  String? parentPhoneNumber4;
  String password;

  User({
    required this.name,
    required this.email,
    required this.userPhoneNumber,
    required this.parentPhoneNumber1,
    this.parentPhoneNumber2,
    this.parentPhoneNumber3,
    this.parentPhoneNumber4,
    required this.password,
  });

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'email': email,
      'user_phone_number': userPhoneNumber,
      'parent_phone_number1': parentPhoneNumber1,
      'parent_phone_number2': parentPhoneNumber2,
      'parent_phone_number3': parentPhoneNumber3,
      'parent_phone_number4': parentPhoneNumber4,
      'password': password,
    };
  }

  factory User.fromMap(Map<String, dynamic> map) {
    return User(
      name: map['name'],
      email: map['email'],
      userPhoneNumber: map['user_phone_number'],
      parentPhoneNumber1: map['parent_phone_number1'],
      parentPhoneNumber2: map['parent_phone_number2'],
      parentPhoneNumber3: map['parent_phone_number3'],
      parentPhoneNumber4: map['parent_phone_number4'],
      password: map['password'],
    );
  }
}
