import 'package:flutter/material.dart';
import 'package:vigilantorb_flutter/emergency.dart';

class UserPage extends StatelessWidget {
  final String userPhoneNumber;
  UserPage({required this.userPhoneNumber});


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home'),
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: () async {
            await sendEmergencyAlert(userPhoneNumber);
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Emergency alert sent!')),
            );
          },
          child: Text('Go to Emergency Page'),
        ),
      ),
    );
  }
}


