

import 'dart:async';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper._internal();
  factory DatabaseHelper() => _instance;
  static Database? _database;

  DatabaseHelper._internal();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    String path = join(await getDatabasesPath(), 'vigilant_orb.db');
    return await openDatabase(
      path,
      version: 1,
      onCreate: _onCreate,
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute(
        '''
      CREATE TABLE admin (
        email TEXT PRIMARY KEY,
        phone_number TEXT,
        password TEXT
      )
      '''
    );

    await db.execute(
        '''
      CREATE TABLE user (
        name TEXT,
        email TEXT,
        user_phone_number TEXT PRIMARY KEY,
        parent_phone_number1 TEXT NOT NULL,
        parent_phone_number2 TEXT,
        parent_phone_number3 TEXT,
        parent_phone_number4 TEXT,
        password TEXT
      )
      '''
    );

    await db.execute(
        '''
      CREATE TABLE parent (
        name TEXT,
        email TEXT,
        parent_phone_number TEXT PRIMARY KEY,
        user_phone_number TEXT,
        password TEXT,
        FOREIGN KEY (user_phone_number) REFERENCES user(user_phone_number)
      )
      '''
    );

  }


  // Admin CRUD operations
  Future<int> insertAdmin(Map<String, dynamic> row) async {
    final db = await database;
    return await db.insert('admin', row);
  }

  Future<List<Map<String, dynamic>>> queryAllAdmins() async {
    final db = await database;
    return await db.query('admin');
  }
  // Add the following method to the DatabaseHelper class
  Future<Map<String, dynamic>?> queryAdmin(String phoneNumber) async {
    final db = await database;
    final results = await db.query('admin', where: 'phone_number = ?', whereArgs: [phoneNumber]);
    if (results.isNotEmpty) {
      return results.first;
    }
    return null;
  }


  Future<int> updateAdmin(Map<String, dynamic> row) async {
    final db = await database;
    return await db.update('admin', row, where: 'email = ?', whereArgs: [row['email']]);
  }

  Future<int> deleteAdmin(String email) async {
    final db = await database;
    return await db.delete('admin', where: 'email = ?', whereArgs: [email]);
  }
  // Update admin password
  Future<int> updateAdminPassword(String phoneNumber, String newPassword) async {
    final db = await database;
    return await db.update(
      'admin',
      {'password': newPassword},
      where: 'phone_number = ?',
      whereArgs: [phoneNumber],
    );
  }

  // User CRUD operations
  Future<int> insertUser(Map<String, dynamic> row) async {
    final db = await database;
    return await db.insert('user', row);
  }

  Future<List<Map<String, dynamic>>> queryAllUsers() async {
    final db = await database;
    return await db.query('user');
  }

  Future<Map<String, dynamic>?> queryUser(String userPhoneNumber) async {
    final db = await database;
    final results = await db.query('user', where: 'user_phone_number = ?', whereArgs: [userPhoneNumber]);
    if (results.isNotEmpty) {
      return results.first;
    }
    return null;
  }

  Future<int> updateUser(Map<String, dynamic> row) async {
    final db = await database;
    return await db.update('user', row, where: 'user_phone_number = ?', whereArgs: [row['user_phone_number']]);
  }

  Future<int> deleteUser(String userPhoneNumber) async {
    final db = await database;
    return await db.delete('user', where: 'user_phone_number = ?', whereArgs: [userPhoneNumber]);
  }
  // Add this method to your DatabaseHelper class
  // Add this method to your DatabaseHelper class



  // Parent CRUD operations
  Future<int> insertParent(Map<String, dynamic> row) async {
    final db = await database;
    return await db.insert('parent', row);
  }

  Future<List<Map<String, dynamic>>> queryAllParents() async {
    final db = await database;
    return await db.query('parent');
  }

  Future<Map<String, dynamic>?> queryParent(String parentPhoneNumber) async {
    final db = await database;
    final results = await db.query('parent', where: 'parent_phone_number = ?', whereArgs: [parentPhoneNumber]);
    if (results.isNotEmpty) {
      return results.first;
    }
    return null;
  }

  Future<int> updateParent(Map<String, dynamic> row) async {
    final db = await database;
    return await db.update('parent', row, where: 'parent_phone_number = ?', whereArgs: [row['parent_phone_number']]);
  }

  Future<int> deleteParent(String parentPhoneNumber) async {
    final db = await database;
    return await db.delete('parent', where: 'parent_phone_number = ?', whereArgs: [parentPhoneNumber]);
  } // Fetch users by parent phone number using the link table

  // Add this method to the DatabaseHelper class
  Future<List<Map<String, dynamic>>> queryUsersByParentPhoneNumber(String parentPhoneNumber) async {
    final db = await database;
    return await db.query(
      'user',
      where: 'parent_phone_number1 = ? OR parent_phone_number2 = ? OR parent_phone_number3 = ? OR parent_phone_number4 = ?',
      whereArgs: [parentPhoneNumber, parentPhoneNumber, parentPhoneNumber, parentPhoneNumber],
    );
  }
  Future<List<Map<String, dynamic>>> queryParentsByUserPhoneNumber(String userPhoneNumber) async {
    final db = await database;
    return await db.query(
      'parent',
      where: 'user_phone_number = ?',
      whereArgs: [userPhoneNumber],
    );
  }
  Future<Map<String, dynamic>?> getUserByPhoneNumber(String phoneNumber) async {
    final db = await database;
    final result = await db.query('user', where: 'user_phone_number = ?', whereArgs: [phoneNumber]);
    if (result.isNotEmpty) {
      return result.first;
    }
    return null;
  }

  // Fetch parent by phone number
  Future<Map<String, dynamic>?> getParentByPhoneNumber(String phoneNumber) async {
    final db = await database;
    final result = await db.query('parent', where: 'parent_phone_number = ?', whereArgs: [phoneNumber]);
    if (result.isNotEmpty) {
      return result.first;
    }
    return null;
  }

  // Reset password methods
  Future<void> updatePassword(String emailOrPhoneNumber, String newPassword) async {
    final db = await database;
    // Check if the email exists in the user table
    var user = await db.query('user', where: 'email = ?', whereArgs: [emailOrPhoneNumber]);
    if (user.isNotEmpty) {
      await db.update('user', {'password': newPassword}, where: 'email = ?', whereArgs: [emailOrPhoneNumber]);
      return;
    }
    // Check if the phone number exists in the admin table
    var admin = await db.query('admin', where: 'phone_number = ?', whereArgs: [emailOrPhoneNumber]);
    if (admin.isNotEmpty) {
      await db.update('admin', {'password': newPassword}, where: 'phone_number = ?', whereArgs: [emailOrPhoneNumber]);
      return;
    }
    // Check if the phone number exists in the parent table
    var parent = await db.query('parent', where: 'parent_phone_number = ?', whereArgs: [emailOrPhoneNumber]);
    if (parent.isNotEmpty) {
      await db.update('parent', {'password': newPassword}, where: 'parent_phone_number = ?', whereArgs: [emailOrPhoneNumber]);
      return;
    }
    // If no matching email or phone number found, handle accordingly (e.g., show error)
    print('User or admin with email/phone number $emailOrPhoneNumber not found.');
  }


}
