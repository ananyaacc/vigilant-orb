import 'package:flutter/material.dart';
import 'package:shake/shake.dart';

class ShakeDetectorWidget extends StatefulWidget {
  final VoidCallback onPhoneShake;

  ShakeDetectorWidget({required this.onPhoneShake});

  @override
  _ShakeDetectorWidgetState createState() => _ShakeDetectorWidgetState();
}

class _ShakeDetectorWidgetState extends State<ShakeDetectorWidget> {
  ShakeDetector? _shakeDetector;

  @override
  void initState() {
    super.initState();
    _shakeDetector = ShakeDetector.autoStart(onPhoneShake: () {
      widget.onPhoneShake();
    });
  }

  @override
  void dispose() {
    _shakeDetector?.stopListening();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Shake Detector'),
      ),
      body: Center(
        child: Text('Shake your phone to activate the voice assistant.'),
      ),
    );
  }
}
