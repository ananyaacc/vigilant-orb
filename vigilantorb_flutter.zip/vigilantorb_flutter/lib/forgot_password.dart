import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_email_sender/flutter_email_sender.dart';

import 'package:vigilantorb_flutter/database/db_helperr.dart';

void main() {
  runApp(MaterialApp(
    home: ForgotPasswordScreen(),
  ));
}

class ForgotPasswordScreen extends StatefulWidget {
  @override
  _ForgotPasswordScreenState createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  final TextEditingController _emailController = TextEditingController();

  String _resetCode = '';

  // Function to generate a random 6-digit reset code
  String _generateResetCode() {
    Random random = Random();
    return (100000 + random.nextInt(900000)).toString();
  }

  // Function to send reset code to user's email using the mailer package
  void _sendResetCode(String email, String resetCode) async {
    final Email emailMessage = Email(
      body: 'Your password reset code is: $resetCode',
      subject: 'Password Reset Code',
      recipients: [email],
    );

    try {
      await FlutterEmailSender.send(emailMessage);
      print('Message sent successfully');
      // Navigate to verify code screen
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => VerifyCodeScreen(
            resetCode: resetCode,
            onVerify: _verifyResetCode,
          ),
        ),
      );
    } catch (e) {
      print('Error sending email: $e');
    }
  }

  void _verifyResetCode(String resetCode) {
    if (resetCode == _resetCode) {
      // Code is correct, allow user to reset password
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => ResetPasswordScreen(),
          settings: RouteSettings(
            arguments: _emailController.text, // Pass the email or phone number
          ),
        ),
      );
    } else {
      // Incorrect code, show error message
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text('Error'),
          content: Text('Invalid reset code. Please try again.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('OK'),
            ),
          ],
        ),
      );
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Forgot Password'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: _emailController,
              decoration: InputDecoration(labelText: 'Email'),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                _resetCode = _generateResetCode();
                _sendResetCode(_emailController.text, _resetCode);
              },
              child: Text('Send Reset Code'),
            ),
          ],
        ),
      ),
    );
  }
}

class VerifyCodeScreen extends StatelessWidget {
  final String resetCode;
  final Function(String) onVerify;

  const VerifyCodeScreen({
    required this.resetCode,
    required this.onVerify,
  });

  @override
  Widget build(BuildContext context) {
    final TextEditingController _codeController = TextEditingController();

    return Scaffold(
      appBar: AppBar(
        title: Text('Verify Code'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: _codeController,
              decoration: InputDecoration(labelText: 'Reset Code'),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () => onVerify(_codeController.text),
              child: Text('Verify Code'),
            ),
          ],
        ),
      ),
    );
  }
}

class ResetPasswordScreen extends StatefulWidget {
  @override
  _ResetPasswordScreenState createState() => _ResetPasswordScreenState();
}

class _ResetPasswordScreenState extends State<ResetPasswordScreen> {
  final TextEditingController _newPasswordController = TextEditingController();
  final TextEditingController _confirmPasswordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Reset Password'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: _newPasswordController,
              decoration: InputDecoration(labelText: 'New Password'),
              obscureText: true,
            ),
            SizedBox(height: 16.0),
            TextField(
              controller: _confirmPasswordController,
              decoration: InputDecoration(labelText: 'Confirm Password'),
              obscureText: true,
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () async {
                // Check if passwords match
                if (_newPasswordController.text == _confirmPasswordController.text) {
                  // Retrieve email or phone number from the input
                  final emailOrPhoneNumber = ModalRoute.of(context)?.settings.arguments as String;
                  // Reset password in the database
                  await DatabaseHelper().updatePassword(
                    emailOrPhoneNumber,
                    _newPasswordController.text,
                  );
                  print('Password reset successfully');
                  // Show a success message
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Password reset successfully!')),
                  );
                  // Go back to login screen
                  Navigator.pop(context);
                } else {
                  // Passwords don't match, show error message
                  showDialog(
                    context: context,
                    builder: (context) => AlertDialog(
                      title: Text('Error'),
                      content: Text('Passwords do not match. Please try again.'),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: Text('OK'),
                        ),
                      ],
                    ),
                  );
                }
              },
              child: Text('Reset Password'),
            ),
          ],
        ),
      ),
    );
  }
}
